/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import DataEstructures.QueueArrayGeneric;
import DataEstructures.StackArrayGeneric;
import DataEstructures.StackrefGeneric;
import DataEstructures.QueurefGeneric;

/**
 *
 * @author ANGEL
 */
public class ConsultAllArticles {
    
    public void consultAllArt_StackRef(StackrefGeneric stack){
        
        stack.checkAll();
        
    }
    
    public void consultAllArt_StackArray(StackArrayGeneric stack){
        
        stack.checkAll();
        
    }
    
    public void consultAllArt_QueueRef(QueurefGeneric queue){
        
        queue.checkAll();
        
    }
    
    public void consultAllArt_QueueArray(QueueArrayGeneric queue){
        
        queue.checkAll();
        
    }
    
    
}
