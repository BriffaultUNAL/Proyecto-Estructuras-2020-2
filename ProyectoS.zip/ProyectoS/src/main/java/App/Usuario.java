
package App;

import java.util.Random;

public class Usuario {
    
    private final int Indentificacion;
    private final String Nombre;
    private final String contrasena;

    public Usuario(int Indentificacion, String Nombre, String contrasena) {
        this.Indentificacion = Indentificacion;
        this.Nombre = Nombre;
        this.contrasena = contrasena;
    }

    public int getIndentificacion() {
        return Indentificacion;
    }

    public String getNombre() {
        return Nombre;
    }
    public String getContrasena() {
        return contrasena;
    }

    
    public Object CrearUsuarioAleatorio(){
        Random random = new Random();
        char[] chars = "abcdfghijklmñnopqrstuvwxyz".toCharArray();
        char[] chars2 = "abcdfghijklmñnopqrstuvwxyz".toCharArray();
        int s ;
        char c ;
        char p ;
        s = (int) (Math.random()*1000);
        c = chars[random.nextInt(chars.length)];
        p = chars[random.nextInt(chars.length)];
        Usuario Usuario1 = new Usuario(s,String.valueOf(c), String.valueOf(p));
        return Usuario1;
    }
    
    
}
