/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;
import java.util.*;

/**
 *
 * @author ANGEL
 */
public class GenerateRandom {
    
    public static String generateRandomWord(int wordLength) {
       Random r = new Random(); // Intialize a Random Number Generator with SysTime as the seed
       StringBuilder sb = new StringBuilder(wordLength);
       for(int i = 0; i < wordLength; i++) { // For each letter in the word
           char tmp = (char) ('a' + r.nextInt('z' - 'a')); // Generate a letter between a and z
           sb.append(tmp); // Add it to the String
       
       }
       return sb.toString();
       
     }
    
    
    public static int generateNum(){
        return (int) (Math.random()*100+1);
    }
    
    public static double generateNumDouble(){
        return (Math.random()*10+1);
    }
}
