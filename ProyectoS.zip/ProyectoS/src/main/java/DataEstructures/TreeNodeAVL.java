/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

/**
 *
 * @author ANGEL
 */
public class TreeNodeAVL <T> {
    T item;
    int num, fe;
    TreeNodeAVL<T> leftSon;
    TreeNodeAVL<T> righttSon;

    public TreeNodeAVL(int num, T item) {
        this.num=num;
        this.item=item;
        this.leftSon=null;
        this.righttSon=null;
    }
    
}
