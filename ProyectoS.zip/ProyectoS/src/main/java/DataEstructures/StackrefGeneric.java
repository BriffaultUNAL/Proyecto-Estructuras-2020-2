package DataEstructures;

import App.Articulos;
import App.GenerateRandom;
import DataEstructures.Nodo;
import java.io.*;
import java.util.Scanner;
import static Interfaz.interfaz_principal.ids;

public class StackrefGeneric<T> {
    
    private Nodo<T> top;    
    private int size;
    
    public StackrefGeneric(){
        
        top=null;
        this.size=0;
         
    }
    
    public boolean isEmpty(){
        return top ==null;
    }
    
    public int size(){
        return this.size;
    }
    
    public T pop(){
        
        if (isEmpty()){
            throw new RuntimeException("Stack is empty");
        }else{
            T item=top.getItem();
            Nodo<T> aux=top.getNext();
            top=null;
            top=aux;
            return item;
        }
    }
    
    public void push(T item){
        
        Nodo <T> aux=new Nodo<>(item,top);
        top=aux;
        this.size++;
        
    }
    
    public T top(){
        
        if(isEmpty()){
            throw new RuntimeException("Stack is empty");
        }else{
            return top.getItem();
        }
        
    }
    
    public boolean search(T item){
        if(isEmpty()){
                return false;
            }
        boolean found=false;
        Nodo aux=top;
        
        while(aux!=null && !found){
            if((T)aux.getItem()==item){
                found=true;
                
            }
            aux=aux.getNext();
        }
        
        return found;
    }
    
    public boolean update(T item, T updatedItem){
            boolean updated=false;
            if(isEmpty()){
                
                updated=false;
                
            }else{
                Nodo aux=top;
        
                while(top!=null && !updated){
                    if((T)top.getItem()==item){
                        updated=true;
                        top.setItem(updatedItem);
                
                    }
                    top=top.getNext();
                }
                top=aux;
            }
            
            return updated;
        }
    
    public boolean elim(T item) {
        boolean elim=false;
            if(isEmpty()){
                
                elim=false;
                
            }else{
                Nodo<T> aux=top;
        
                while(aux!=null && !elim){
                    
                    if((T)aux.getItem()==item){
                        Nodo<T> aux2=aux.getNext();
                        
                        aux=null;
                        
                        aux=aux2;
                        elim=true;
                
                    }
                    aux=aux.getNext();
                }
                
            }
            
            return elim;
        
        
    }
    
    public void checkAll(){
            if(isEmpty()){
                System.err.println("Stack is empty");
            }else{
                Nodo aux=top;
                
                while(aux!=null){
                    
                    System.out.println(aux.getItem());
                    aux=aux.getNext();
                    
                }
            }
            
            
        }
    
    String barra=File.separator;
    
    
    	
	public void save(StackrefGeneric stack, String name) {
            
            String ubicacion = ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		FileWriter fl = null;
		try {
                    
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!stack.isEmpty()) {
				//escribe los datos en el archivo
                                Articulos articulo=(Articulos)stack.pop();
				fl.write(articulo.getName()+ "," +
                                        String.valueOf(articulo.getCode()) + "," +
                                        articulo.getImage()+ "," +
                                        String.valueOf(articulo.getPrice()) + "," +
                                        String.valueOf(articulo.getAntiquity()) + "," +
                                        articulo.getBrand() + "," +
                                        articulo.getDescription()+ "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        public StackrefGeneric chrage_file(String name) {
            
            String ubicacion = ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		StackrefGeneric stack= new StackrefGeneric<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               stack.push(articulo);
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
                System.out.println(stack.size());
		return stack;
	}
    
}
    




