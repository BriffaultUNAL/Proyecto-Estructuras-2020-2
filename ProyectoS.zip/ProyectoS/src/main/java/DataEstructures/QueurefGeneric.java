/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

import App.Articulos;
import DataEstructures.Nodo;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ANGEL
 */
public class QueurefGeneric<T> {
    
    private Nodo<T> front;
    private Nodo<T> rear;
    private int size;
    
    public QueurefGeneric(){
        
        front = null;
        rear=null;
        size=0;
    }
    
    public boolean isEmpty(){
        return size<=0;
    }
    
    public int size(){
        return size;
    }
    
    public T dequeue(){
        T item=front.getItem();
        Nodo aux=front.getNext();
        if (isEmpty()){
            throw new RuntimeException("queue is empty");
        }else{
            front=null;
            front=aux;
            size--;
            if(isEmpty()){
                rear=null;
            }
        }
        return item;
    }
    
    public T enqueue(T item){
        
        Nodo aux=new Nodo(item,null);
        
        if (isEmpty()){
            front=aux;
            rear=aux;
        }else{
            if (size==1){
                front.setNext(aux);
            }else{
                rear.setNext(aux);
            }
            rear=aux;
        }
        size++;
        return (T) aux.getItem();
    }
    
    public boolean search(T item){
        
        if(isEmpty()){
                return false;
            }
        boolean found=false;
        Nodo aux=front;
        
        while(aux!=null && !found){
            if((T)aux.getItem()==item){
                found=true;
                
            }
            aux=aux.getNext();
        }
        
        return found;
    }
    
    public boolean update(T item, T updatedItem){
            boolean updated=false;
            if(isEmpty()){
                
                updated=false;
                
            }else{
                Nodo aux=front;
        
                while(front!=null && !updated){
                    if((T)front.getItem()==item){
                        updated=true;
                        front.setItem(updatedItem);
                
                    }
                    front=front.getNext();
                }
                front=aux;
            }
            
            return updated;
        }
    
    public void checkAll(){
            if(isEmpty()){
                System.err.println("Queue is empty");
            }else{
                Nodo aux=front;
                
                while(aux!=null){
                    
                    System.out.println(aux.getItem());
                    aux=aux.getNext();
                    
                }
            }
            
            
        }
    
    
        String barra=File.separator;
        
    	public void save(QueurefGeneric queue, String name) {
            
            String ubicacion=System.getProperty("user.dir")+barra+name+barra;
		FileWriter fl = null;
		try {
                    
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!queue.isEmpty()) {
				//escribe los datos en el archivo
                                Articulos articulo=(Articulos)queue.dequeue();
				fl.write(articulo.getName()+ "," +
                                        String.valueOf(articulo.getCode()) + "," +
                                        articulo.getImage()+ "," +
                                        String.valueOf(articulo.getPrice()) + "," +
                                        String.valueOf(articulo.getAntiquity()) + "," +
                                        articulo.getBrand() + "," +
                                        articulo.getDescription()+ "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        
        
        public QueurefGeneric chrage_file(String name) {
            
            String ubicacion=System.getProperty("user.dir")+barra+name+barra;
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		QueurefGeneric<Object> queue= new QueurefGeneric<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               queue.enqueue(articulo);
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return queue;
	}
}
