/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

import App.Articulos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ANGEL
 */
public class QueueArrayGeneric<T>{
    
        private int front, rear, count, size, upda;
        private T[] qarray;
        
        public QueueArrayGeneric(int n) {
        front = rear = count = 0;
        size=n;
        qarray = (T[]) new Object[size];
        }
        
        public T dequeue() {
            T item = null;
            if(empty())
                throw new RuntimeException("queue is empty");
            else {
            item = qarray[front];
            front = (front + 1) % size;
            count--;
            }
            return item;
        }
        
        public void enqueue(T item) {
            if(full())
                throw new RuntimeException("queue is full");
            else {
            qarray[rear] = item;
            rear = (rear + 1) % size;
            count++;
        }
    }
        
        public boolean empty() {
            return count <= 0;
        }
        
        public boolean full() {
            return count >= size;
        }
        
        public int getCount() {
            return count;
    }
        
        public boolean search(T item) {
            if(empty()){
                return false;
            }
            
            boolean found;
            found = false;
            int position = 0;

            while(position != count && !found){
            if(qarray[position] == item){
                found = true;
                upda=position;
                }else{
                    position++;
                }
            }
            return found;
        }
        
        public boolean update(T item, T updatedItem){
            boolean updated=false;
            if(empty()){
                
                updated= false;
                
            }else{
                if(!search(item)){
                
                updated=false;

            }else{
            
                qarray[upda]=updatedItem;
            updated=true;
                 
            }
            
            
            }
            return updated;
        }
        
        public void checkAll(){
            if(empty()){
                System.err.println("Queue is empty");
            }else{
                for(int i=count-1;i>=0;i--){
                    
                    System.out.println(qarray[i]);
                
                }
            }
            
            
        }
        
                String barra=File.separator;
        
    	public void save(QueueArrayGeneric queue, String name) {
            
            String ubicacion=System.getProperty("user.dir")+barra+name+barra;
		FileWriter fl = null;
		try {
                    
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!queue.empty()) {
				//escribe los datos en el archivo
                                Articulos articulo=(Articulos)queue.dequeue();
				fl.write(articulo.getName()+ "," +
                                        String.valueOf(articulo.getCode()) + "," +
                                        articulo.getImage()+ "," +
                                        String.valueOf(articulo.getPrice()) + "," +
                                        String.valueOf(articulo.getAntiquity()) + "," +
                                        articulo.getBrand() + "," +
                                        articulo.getDescription()+ "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        
        
        public QueueArrayGeneric chrage_file(String name, int num) {
            
            String ubicacion=System.getProperty("user.dir")+barra+name+barra;
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		QueueArrayGeneric<Object> queue= new QueueArrayGeneric<>(num);	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               queue.enqueue(articulo);
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return queue;
	}
}
        
