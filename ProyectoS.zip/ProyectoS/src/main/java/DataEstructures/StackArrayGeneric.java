/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

import App.Articulos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import static Interfaz.interfaz_principal.ids;
/**
 *
 * @author ANGEL
 */
public class StackArrayGeneric<T> {
    
        private int top,upda;
        private T[] sarray;
        
        public StackArrayGeneric(int n) {
            top = 0;
            sarray = (T[]) new Object[n];
        }

        public boolean empty() {
            return top <= 0;
        }
        
        private boolean full() {
            return top >= sarray.length;
        }
        public T pop() {
            if(empty())
                throw new RuntimeException("Stack is empty");
            top--;
            return sarray[top];
        }

        public void push(T item) {
            if(full())
                throw new RuntimeException("Stack is full");
            sarray[top]=item;
            top++;
        }
        
        public boolean search(T item) {
            if(empty()){
                return false;
            }
            boolean found;
            found = false;
            int position = 0;

            while(position != top && !found){
            if(sarray[position] == item){
                found = true;
                upda=position;
                }else{
                    position++;
                }
            }
            return found;
        }
        
        public boolean update(T item, T updatedItem){
            boolean updated=false;
            if(empty()){
                
                updated= false;
                
            }else{
                if(!search(item)){
                
                updated=false;

            }else{
            
                    sarray[upda]=updatedItem;
            updated=true;
                 
            }
                        
            }
            return updated;
        }
        
        public void checkAll(){
            if(empty()){
                System.err.println("Queue is empty");
            }else{
                for(int i=top-1;i>=0;i--){
                    
                    System.out.println(sarray[i]);
                
                }
            }
            
            
        }
        
            String barra=File.separator;
    
    
    	
	public void save(StackArrayGeneric stack, String name) {
            
            String ubicacion= ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		FileWriter fl = null;
		try {
                    
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!stack.empty()) {
				//escribe los datos en el archivo
                                Articulos articulo=(Articulos)stack.pop();
				fl.write(articulo.getName()+ "," +
                                        String.valueOf(articulo.getCode()) + "," +
                                        articulo.getImage()+ "," +
                                        String.valueOf(articulo.getPrice()) + "," +
                                        String.valueOf(articulo.getAntiquity()) + "," +
                                        articulo.getBrand() + "," +
                                        articulo.getDescription()+ "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        public StackArrayGeneric chrage_file(String name, int num) {
            
            String ubicacion= ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		StackArrayGeneric<Object> stack= new StackArrayGeneric<>(num);	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               stack.push(articulo);
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
		                  System.out.println("Error en chrage_files de stackArrayGeneric");	
                    e.printStackTrace();
		}
		return stack;
	}
}
