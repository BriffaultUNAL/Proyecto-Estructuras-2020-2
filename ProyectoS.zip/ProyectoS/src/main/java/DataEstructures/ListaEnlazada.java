 
package DataEstructures;

import App.Articulos;
import App.Usuario;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ListaEnlazada<T> {
    
    public class NodoGeneric<T>{
        public T data;
        private NodoGeneric<T> next;

        public NodoGeneric() {
            this(null);
        }
        
        public NodoGeneric(T data){
            this.data = data;
            this.next = null; 
        }

        public T getData() {
            return data;
        }

        public void setData(T data) {
            this.data = data;
        }

        public NodoGeneric<T> getNext() {
            return next;
        }

        public void setNext(NodoGeneric<T> next) {
            this.next = next;
        } 
        
    }
    
    private NodoGeneric cabeza;
    private NodoGeneric cola;
    
    public ListaEnlazada(){
        cabeza = null;
        cola = null;
     }
    
    public boolean isEmpty(){
        return cabeza == null;
    }
    
    public void InsetarDatoAlFinalSinCola(T item){
        NodoGeneric apuntador ; 
        NodoGeneric NuevoNodo = new NodoGeneric();
        NuevoNodo.data = item; 
        apuntador = cabeza; 
        while(apuntador.next != null){
            apuntador = apuntador.next;
        }
        apuntador.next = NuevoNodo;
        NuevoNodo.next = null;
        
    }
    
    public void InsertarAlInicioSinCola(T item){
        NodoGeneric NuevoNodo = new NodoGeneric() ; 
        NuevoNodo.data = item ; 
        NuevoNodo.next = cabeza ;
        cabeza = NuevoNodo ; 
        if (cabeza == null)
                cabeza = NuevoNodo;
    }
    
    
    public T SacarDelInicioSinCola(){
        NodoGeneric Apuntador ; 
        Apuntador = cabeza ;
        if (cabeza == null)
            System.out.println("La Lista esta vacia");
        cabeza = cabeza.next;
        return (T) Apuntador.data;
    }
    
    public T SacarDelFinalSinCola(){
        NodoGeneric Apuntador; 
        Apuntador = cabeza; 
        NodoGeneric prev; 
        prev = null;
        if(cabeza == null)
            System.out.println("La Lista esta Vacia");
        while(Apuntador.next != null){
            prev = Apuntador;
            Apuntador = Apuntador.next;
        }
        prev.next = null;
        return (T) Apuntador.data;
    }
   
    
    
    public void PushFront(T item){
        NodoGeneric NuevoNodo = new NodoGeneric();
        NuevoNodo.data = item;
        NuevoNodo.next = cabeza;
        cabeza = NuevoNodo;
        if (cola == null)
                cola = cabeza;
    }
    
    public T PopFront(){
        NodoGeneric Apuntador = new NodoGeneric();
        Apuntador = cabeza;
        if (cabeza == null){
            cola = null;
            System.out.println("La Lista Esta Vacia");
        }
        cabeza = cabeza.next;
        return (T) Apuntador.data;
    }
    
    public void PushBack(T item){
        NodoGeneric NodoNuevo = new NodoGeneric();
        NodoNuevo.data = item;
        NodoNuevo.next = null;
        if (cola == null){
            cabeza = NodoNuevo;
            cola = NodoNuevo;
        }else {
            cola.next = NodoNuevo;
            cola = NodoNuevo;
        }
    }
    
    
    
    public T PopBack(){
        NodoGeneric Apuntador = new NodoGeneric();
        Apuntador = cabeza;
        T s;
        s = null;
        if (cabeza == null)
            System.out.println("La Lista Esta vacia");
        else if(cabeza == cola){
            cabeza = null;
            cola = null;
        }else{
            while(Apuntador.next.next != null){
                Apuntador = Apuntador.next;
            }
            s = (T) Apuntador.next.data;
            Apuntador.next = cola;
            cola = Apuntador;
            
        }
        return s ;
    }
    
    public void AddAfter(NodoGeneric node , T item){
        NodoGeneric NuevoNodo = new NodoGeneric();
        NuevoNodo.data = item; 
        NuevoNodo.next = node.next;
        node.next = NuevoNodo;
        if (cola == node)
            cola = NuevoNodo;
    }
    
    public int[] Find(T item){
        int count = 0;
        NodoGeneric indice; 
        for(indice = cabeza ; indice != null ; indice = indice.next){
            count ++;
            if(item == indice.data){
            return new int[] {count,(Integer) indice.data};
            }
        }
        return null;
    }
    
    public T Encontrar(int item){
        NodoGeneric Apuntador;
        Apuntador = cabeza;
        for(int i = 0 ; i< item-1;i++){
            Apuntador = Apuntador.next;
        }
        return (T) Apuntador.data;
    }
    
    public T EliminarSegunIdentificacion(int item){
        NodoGeneric Apuntador;
        Apuntador = cabeza;
        for(int i = 0 ; i< item-1;i++){
            Apuntador = Apuntador.next;
        }
        Apuntador.next = Apuntador.next.next;
        return (T) Apuntador.data;
     }
    
    
     public void PintSinRecursion(){
     NodoGeneric ref ;
     ref = cabeza;
     while(ref != null){
         System.out.println(ref.data);
         ref = ref.next;
     }
     
     
     }
     public void printRecursivo(){
        System.out.println("Lista con MetodoRecusivo: ");
        printR(cabeza);
        System.out.println();
    }
    
    private void printR(NodoGeneric p){
        if(p != null){
            System.out.println(p.data+" ");
            printR(p.next);
        }
    }

    public NodoGeneric getCabeza() {
        return cabeza;
    }

    public NodoGeneric getCola() {
        return cola;
    }
    
            String barra=File.separator;
        
    	public void save(ListaEnlazada list, String name) {
            
            String ubicacion=System.getProperty("user.dir")+barra+name+barra;
		FileWriter fl = null;
		try {
                    
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!list.isEmpty()) {
				//escribe los datos en el archivo
                                Usuario usuario=(Usuario)list.PopFront();
				fl.write(
                                        usuario.getNombre() + "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        
        
        public ListaEnlazada chrage_file(String name) {
            
            String ubicacion=System.getProperty("user.dir")+barra+name+barra;
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		ListaEnlazada<Object> list= new ListaEnlazada<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               list.PushFront(articulo);
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return list;
	}

    
    
}
