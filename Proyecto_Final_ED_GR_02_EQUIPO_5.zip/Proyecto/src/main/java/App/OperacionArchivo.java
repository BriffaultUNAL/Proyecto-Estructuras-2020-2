 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import static Interfaz.interfaz_principal.ids;

/**
 *
 * @author D. Cocoma
 */
public class OperacionArchivo {
    public static void modificar_contador(String s) {
		FileWriter flwriter = null;
		try {
			//crea el flujo para escribir en el archivo
			flwriter = new FileWriter(ids + "\\src\\main\\java\\txt\\cantidad.txt");
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			BufferedWriter bfwriter = new BufferedWriter(flwriter);
			bfwriter.write(s);
			//cierra el buffer intermedio
			bfwriter.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (flwriter != null) {
				try {//cierra el flujo principal
					flwriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public static void crear_us(int id, String usuario, String contrasena) {
		FileWriter flwriter = null;
		try {
			//crea el flujo para escribir en el archivo
			flwriter = new FileWriter(ids + "\\src\\main\\java\\txt\\usuarios\\" + id + ".txt");
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			BufferedWriter bfwriter = new BufferedWriter(flwriter);
			bfwriter.write(usuario + "\n");                        
			bfwriter.write(contrasena);                        
                        
			//cierra el buffer intermedio
			bfwriter.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (flwriter != null) {
				try {//cierra el flujo principal
					flwriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	//crea el archivo en disco, retorna la lista de estudiantes
	public static String leer_contador() {
		// crea el flujo para leer desde el archivo
		File file = new File(ids + "\\src\\main\\java\\txt\\cantidad.txt");
		Scanner scanner;
                String num = "0";
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
			num = scanner.nextLine();
			
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return num;
	}
        public static String[] leer_usuario(int id) {
		// crea el flujo para leer desde el archivo
		File file = new File(ids + "\\src\\main\\java\\txt\\usuarios\\" + id + ".txt");
		Scanner scanner;
                String usu = "0";
                String pass = "0";
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
			usu = scanner.nextLine();
			pass = scanner.nextLine();
			
			scanner.close();
		} catch (FileNotFoundException e) {
                        throw new NullPointerException();
		}
                String[] datos = new String[2];
                datos[0] = usu;
                datos[1] = pass;
		return datos;
	}
    
}
