
package App;

import java.util.Random;

public class Usuario {
    
    private final String Nombre;
    private final String contrasena;

    public Usuario(String Nombre, String contrasena) {
        this.Nombre = Nombre;
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return Nombre;
    }
    public String getContrasena() {
        return contrasena;
    }

    
    public Object CrearUsuarioAleatorio(){
        Random random = new Random();
        char[] chars = "abcdfghijklmñnopqrstuvwxyz".toCharArray();
        char[] chars2 = "abcdfghijklmñnopqrstuvwxyz".toCharArray();
        char c ;
        char p ;
        c = chars[random.nextInt(chars.length)];
        p = chars[random.nextInt(chars.length)];
        Usuario Usuario1 = new Usuario(String.valueOf(c), String.valueOf(p));
        return Usuario1;
    }
    
    
}
