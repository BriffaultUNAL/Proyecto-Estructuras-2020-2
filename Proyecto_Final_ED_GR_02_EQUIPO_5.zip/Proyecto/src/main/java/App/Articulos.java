/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;


/**
 *
 * @author ANGEL
 */
public class Articulos {
    
    private String name;
    private  int code;
    private String image;
    private double price;
    private int antiquity;
    private String brand;
    private String description;

    public Articulos(String name, int code, String image, double price, int antiquity, 
            String brand, String description) {
        this.name = name;
        this.code = code;
        this.image = image;
        this.price = price;
        this.antiquity = antiquity;
        this.brand = brand;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code=code;
    }
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAntiquity() {
        return antiquity;
    }

    public void setAntiquity(int antiquity) {
        this.antiquity = antiquity;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }   
}
