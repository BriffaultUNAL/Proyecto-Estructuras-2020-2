/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import DataEstructures.QueueArrayGeneric;
import DataEstructures.StackArrayGeneric;
import DataEstructures.StackrefGeneric;
import DataEstructures.QueurefGeneric;

/**
 *
 * @author ANGEL
 */
public class SearchArticle {
    
    String object_stackRef;
    String object_stackArray;
    String object_queueuRef;
    String object_queueArray;
    
    StackrefGeneric<String> stackRef=new StackrefGeneric<>();
    StackArrayGeneric<String> stackArray=new StackArrayGeneric<>(100000);
    QueurefGeneric<String> queueRef=new QueurefGeneric<>();
    QueueArrayGeneric<String> queueArray=new QueueArrayGeneric<>(100000);
    
   public void create_and_enter_stackRef(int num){
       
       object_stackRef=GenerateRandom.generateRandomWord(10);
       
       stackRef.push(object_stackRef);
               
        for(int i=1;i<num;i++){
         
            stackRef.push(GenerateRandom.generateRandomWord(10));
            
        }
        
    }
   
   public void create_and_enter_stackArray(int num){
       
       object_stackArray=GenerateRandom.generateRandomWord(10);
       
       stackArray.push(object_stackArray);
               
        for(int i=1;i<num;i++){
         
            stackRef.push(GenerateRandom.generateRandomWord(10));
            
        }
        
    }
   
   public void create_and_enter_queueRef(int num){
               
        for(int i=1;i<num-1;i++){
         
            queueRef.enqueue(GenerateRandom.generateRandomWord(10));
            
        }
        
       object_queueuRef=GenerateRandom.generateRandomWord(10);
       
       queueRef.enqueue(object_queueuRef);
        
    }
   
   public void create_and_enter_queuekArry(int num){
       
       for(int i=0;i<num-1;i++){
         
            queueArray.enqueue(GenerateRandom.generateRandomWord(10));
            
        }
        
       object_queueArray=GenerateRandom.generateRandomWord(10);
       
       queueArray.enqueue(object_stackRef);
            
        }
   
   public boolean searchArt_stackRef(){
       if(stackRef.search(object_stackRef)){
           return true;
       }else{
           return false;
       }   
       
   }
   
   public boolean searchArt_stackarray(){
       
       if(stackArray.search(object_stackArray)){
       return  true;
       }else{
           return false;
       }
       
   }
   
   public boolean searchArt_queueRef(){
       
       if(queueRef.search(object_queueuRef)){
           return true;
       }else{
           return false;
       }
       
   }
   
   public boolean searchArt_queueArray(){
       
       if(queueArray.search(object_queueArray)){
           return true;
       }else{
           return false;
       }
       
   }
        
}
    

