/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import DataEstructures.QueueArrayGeneric;
import DataEstructures.StackArrayGeneric;
import DataEstructures.StackrefGeneric;
import DataEstructures.QueurefGeneric;
import DataEstructures.BinaryTree;

/**
 *
 * @author ANGEL
 */
public class CreateAndEnterArticles {
    

    public StackrefGeneric create_and_enter_stackRef(int num){
        
        StackrefGeneric<Object> stackRef=new StackrefGeneric<>();
        
        for(int i=0;i<num;i++){
            
            
            Articulos articulo = new Articulos(GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNumDouble(),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateRandomWord(10));
            stackRef.push(articulo);
        }
        
        return stackRef;
        
    }
    
    public StackArrayGeneric create_and_enter_stackArray(int num){
        
        StackArrayGeneric<Object> stackArray=new StackArrayGeneric<>(num);
        
        for(int i=0;i<num;i++){
            
            
            Articulos articulo = new Articulos(GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNumDouble(),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateRandomWord(10));
            stackArray.push(articulo);
        }
        
        return stackArray;
        
    }
    
    public QueurefGeneric create_and_enter_queueRef(int num){
        
        QueurefGeneric<Object> queueRef=new QueurefGeneric<>();
        
        for(int i=0;i<num;i++){
            
            
            Articulos articulo = new Articulos(GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNumDouble(),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateRandomWord(10));
            queueRef.enqueue(articulo);
        }
        
        return queueRef;
        
    }
    
    public QueueArrayGeneric create_and_enter_queueStackArray(int num){
        
        QueueArrayGeneric<Object> queueArray=new QueueArrayGeneric<>(num);
        
        for(int i=0;i<num;i++){
            
            
            Articulos articulo = new Articulos(GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNumDouble(),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateRandomWord(10));
            queueArray.enqueue(articulo);
        }
        
        return queueArray;
        
    }

    public BinaryTree create_and_enter_binaryTree(int num){
        
        BinaryTree<Object> binaryTree=new BinaryTree<>();
        
        for(int i=0;i<num;i++){
            
            
            Articulos articulo = new Articulos(GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateNumDouble(),
                                        GenerateRandom.generateNum(),
                                        GenerateRandom.generateRandomWord(10),
                                        GenerateRandom.generateRandomWord(10));
            binaryTree.insertNode(articulo,articulo.getCode());
        }
        
        return binaryTree;
        
    }
    
    
}
