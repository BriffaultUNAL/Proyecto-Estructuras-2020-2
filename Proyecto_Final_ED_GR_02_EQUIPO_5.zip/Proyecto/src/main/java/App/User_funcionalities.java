package App;

import App.Usuario;
import DataEstructures.ListaEnlazada;
import java.util.Scanner;
import java.util.Random;
import DataEstructures.AVL;
import DataEstructures.ListaEnlazada.NodoGeneric;


public class User_funcionalities {
    
    public static AVL binaryTree = new AVL();

    ListaEnlazada<Object> Lista1 = new ListaEnlazada<>();
    ListaEnlazada<Integer> Lista2 = new ListaEnlazada<>();
    Usuario Usuario = new Usuario("d", "s");
    Usuario Usuario1 = new Usuario("d", "s");
    Scanner scanner = new Scanner(System.in);
      Random random = new Random();
      char[] chars = "abcdfghijklmñnopqrstuvwxyz".toCharArray();
      int s =0;
      int r = 0;
      char c ;
      
      //Busqueda de Usuarios segun su identificacion

      //Lista2.PintSinRecursion();
      /*
      long inicio = System.currentTimeMillis();
      long fin = System.currentTimeMillis();
      double tiempo = (double) ((fin - inicio));
      System.out.println(tiempo +" milisegundos");
      */
      
 
    public void create_random_users(int num){
        for(int i = 1 ; i<=num; i++){
          Usuario1 = (Usuario) Usuario.CrearUsuarioAleatorio();
          binaryTree.setRaiz(binaryTree.Insert(Usuario.getNombre(),
                                    Usuario.getContrasena(), binaryTree.getRaiz()));
      }
    }
     public void save(){
         
         binaryTree.saveUser(binaryTree, "usuarios3");
         //binaryTree.inOrden(binaryTree.getRoot());
    }
    public void create_user(String name, String password){
        binaryTree=binaryTree.chrageFileUser("usuarios3");
        binaryTree.setRaiz(binaryTree.Insert(name,
                                    password, binaryTree.getRaiz()));
    }
    
    public void search_user(int num){
      
      //System.out.println(binaryTree.search(num));
    }
    
    public void Consult_users(){
        binaryTree.preOrden(binaryTree.getRaiz());
    }
    
}
