/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import DataEstructures.StackrefGeneric;
import java.io.File;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ANGEL
 */
public class Files implements Serializable{
        
    String barra=File.separator;
    String ubicacion=System.getProperty("user.dir")+barra+"newArch"+barra;
    
    	//crea el archivo en disco, recibe como parámetro la lista de estudiantes
	public void crearArchivo(int num) {
		FileWriter fl = null;
		try {
                    
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			for (int i=0;i<num;i++) {
				//escribe los datos en el archivo
				fl.write(GenerateRandom.generateRandomWord(10)+ "," +
                                        String.valueOf(GenerateRandom.generateNum()) + "," +
                                        GenerateRandom.generateRandomWord(10)+ "," +
                                        String.valueOf(GenerateRandom.generateNumDouble()) + "," +
                                        String.valueOf(GenerateRandom.generateNum()) + "," +
                                        GenerateRandom.generateRandomWord(10) + "," +
                                        GenerateRandom.generateRandomWord(10)+ "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        public StackrefGeneric leerArchivo(int num) {
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		StackrefGeneric stack= new StackrefGeneric<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        for (int i=0;i<num;i++){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               stack.push(articulo);
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
                System.out.println(stack.size());
		return stack;
	}
		
    
  /*   String barra=File.separator;
    String ubicacion=System.getProperty("user.dir")+barra+"archivos"+barra;
    
    public void write(String name){
        
        
        File crea_ubicacion=new File(ubicacion);
        File crea_archivo =new File(ubicacion+name);
        crea_ubicacion.mkdirs();
        try {
            Formatter crea=new Formatter(ubicacion+name);
            crea.format("%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n%s"
                    ,"name="+GenerateRandom.generateRandomWord(10)
                    ,"quantity="+String.valueOf(GenerateRandom.generateNum())
                    ,"image="+GenerateRandom.generateRandomWord(10)
                    ,"price="+String.valueOf(GenerateRandom.generateNumDouble())
                    ,"antiquity="+String.valueOf(GenerateRandom.generateNum())
                    ,"brand="+GenerateRandom.generateRandomWord(10)
                    ,"description="+GenerateRandom.generateRandomWord(10));
            crea.close();
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        }     
    }
    
    public Repuestos read(String name){
        Repuestos repuesto=null;
        File url=new File(ubicacion+name);
        try {
            FileInputStream file= new FileInputStream(url);
            Properties mostrar=new Properties();
            try {
                mostrar.load(file);

                    Repuestos respuesto =new Repuestos(mostrar.getProperty("name")
                        ,Integer.parseInt(mostrar.getProperty("quantity"))
                        ,mostrar.getProperty("image")
                        ,Double.parseDouble(mostrar.getProperty("price"))
                        , Integer.parseInt(mostrar.getProperty("antiquity"))
                        , mostrar.getProperty("brand")
                        , mostrar.getProperty("description"));
                    
                    
                
                
            } catch (IOException ex) {
                Logger.getLogger(Files.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());
        }
        return repuesto;
    }
    
   public void output(String name, int quantity){
        
        File archivo=new File(name);
        FileOutputStream output = null;
        StackrefGeneric<Object> stack=new StackrefGeneric<>();
        
        try {
            System.out.println("Escribiendo en archivo");
            archivo.createNewFile();
            output=new FileOutputStream(archivo);
            ObjectOutputStream writer=new ObjectOutputStream(output); 
            for (int i=0;i<2000;i++){
                Repuestos repuesto=new Repuestos(GenerateRandom.generateRandomWord(10),GenerateRandom.generateNum()
                   ,GenerateRandom.generateRandomWord(20),GenerateRandom.generateNumDouble(),GenerateRandom.generateNum()
                   ,GenerateRandom.generateRandomWord(10),GenerateRandom.generateRandomWord(10));
                stack.push(repuesto);
            }
            writer.writeObject(stack);
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        finally{
            if(output!=null){
                try {
                    output.close();
                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
        
    }
    
    public StackrefGeneric input(String name, StackrefGeneric stack) {
        
        File archivo=new File(name);
        FileInputStream input=null;
        ObjectInputStream reader=null;
                  
        try {
            input=new FileInputStream(archivo);
            try { 
                reader =new ObjectInputStream(input);
                try {
                    stack=(StackrefGeneric<Object>)reader.readObject();
                } catch (ClassNotFoundException ex) {
                    System.err.println(ex.getMessage());
                }
            } catch (IOException ex) {
                System.err.println(ex.getMessage());
            }
                    }
         catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());
        }
        finally{
            if(reader!=null){
                try {
                    reader.close();
                } catch (IOException ex) {
                     System.err.println(ex.getMessage());
                }
            }
        }

        return stack;
    }*/
    
}
