
package App;

import DataEstructures.QueueArrayGeneric;
import DataEstructures.StackArrayGeneric;
import DataEstructures.StackrefGeneric;
import DataEstructures.QueurefGeneric;
import DataEstructures.BinaryTreeAVL;
import DataEstructures.BinaryTree;

public class Main {
    public static void main(String[] args) throws Exception {
        
        QueurefGeneric<Integer> queueRef = new QueurefGeneric<>();
        StackArrayGeneric<Integer> stackArray=new StackArrayGeneric<>(100);
        StackrefGeneric<Object> stackRef=new StackrefGeneric<>();
        QueueArrayGeneric queueArray=new QueueArrayGeneric<>(100);
        BinaryTreeAVL<Integer> binaryTreeAVL=new BinaryTreeAVL<>();
        BinaryTree<Integer> binaryTree=new BinaryTree<>();
        
        
        CreateAndEnterArticles create_Art = new CreateAndEnterArticles();
        ConsultAllArticles consult_all=new ConsultAllArticles();
        SearchArticle searchArt=new SearchArticle();
        User_funcionalities user_func =new User_funcionalities();
        
        
        user_func.create_random_users(100);
        //user_func.Consult_users();
        user_func.save();
        System.out.println("jajs");
        
        
        //Ingresar usuarios, consultar
        
        /*
        
        long inicio = System.currentTimeMillis();
        
        user_func.create_random_users(10000);
        user_func.Consult_users();
  
        long fin = System.currentTimeMillis();
         
        double tiempo = (double) ((fin - inicio));
        
        System.out.println(tiempo+"milisegundos");
        */
        
        //Ingresar articulo,mostrar articulos
        
        /*
        long inicio = System.currentTimeMillis();
        
        stackArray=create_Art.create_and_enter_stackArray(10);
        
        queueRef=create_Art.create_and_enter_queueRef(100);
        
        consult_all.consultAllArt_StackArray(stackArray);
        System.out.println("");
        System.out.println("");
        consult_all.consultAllArt_QueueRef(queueRef);
                
        user_func.Consult_users();
  
        long fin = System.currentTimeMillis();
         
        double tiempo = (double) ((fin - inicio));
        
        System.out.println(tiempo+"milisegundos");
        
        */
        //buscar producto
        /*
        long inicio = System.currentTimeMillis();
        
        searchArt.create_and_enter_queueRef(1000);
        
        searchArt.create_and_enter_stackArray(100000);
        
        System.out.println(searchArt.searchArt_queueRef());
        System.out.println(searchArt.searchArt_stackarray());
  
        long fin = System.currentTimeMillis();
         
        double tiempo = (double) ((fin - inicio));
        
        System.out.println(tiempo+"milisegundos");
        
        
        long inicio = System.currentTimeMillis();
        
        stackArray=create_Art.create_and_enter_stackArray(1000);
        stackArray.save(stackArray, "Prueba");
        queueArray=queueArray.chrage_file("prueba", 1000);
 
        while(!queueArray.empty()){
            System.out.println(queueArray.dequeue());
        }
       
  
        long fin = System.currentTimeMillis();
         
        double tiempo = (double) ((fin - inicio));
        
        System.out.println(tiempo+"milisegundos");
        
        /*
        
        
           for(int i=0;i<100;i++){
        queue.enqueue(i);
        stack.push(i);
    }
   
        
    //while(!queue.isEmpty()){
      //  System.out.println(queue.dequeue());
    //}    
    

        //Files f=new Files();

        //f.crearArchivo(100000000);
        
                      //mostrar((StackrefGeneric<Object>) stack.pop());
    
        
       stack=f.leerArchivo(100);
       
        System.out.println(stack.size());
       
        while (!stack.isEmpty()) {            
            System.out.println(stack.pop());
        }
                      
                      
*/

    }
    
 

                      
}