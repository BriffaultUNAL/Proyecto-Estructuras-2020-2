/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

import App.Articulos;
import App.Usuario;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ANGEL
 */
public class AVLarticles {
    StackrefGeneric <NodoAVLarticles> stack = new StackrefGeneric<>();
    NodoAVLarticles Raiz;
    NodoAVLarticles Aux; 

    public NodoAVLarticles getAux() {
        return Aux;
    }

    public void setAux(NodoAVLarticles Aux) {
        this.Aux = Aux;
    }


    public void setRaiz(NodoAVLarticles Raiz) {
        this.Raiz = Raiz;
    }
    
    

    public void preOrden(NodoAVLarticles n){
        if(empty()){
            //throw new RuntimeException("Tree is empty");
            System.err.println(n.data);
        }else{
            if(n!=null){
                System.out.println(n.data);
                preOrden(n.left);
                preOrden(n.right);
                }
            }
    }
    
    
    public NodoAVLarticles getRaiz(){
        return Raiz;
    }
    
    public static int Altura(NodoAVLarticles N){
        if(N== null)
            return 0;

        return N.altura;
    }

    public static NodoAVLarticles RotacionDer(NodoAVLarticles R){
        NodoAVLarticles x = R.left;
        NodoAVLarticles T2 = x.right;

        x.right = R;
        R.left = T2;

        R.altura = (int) (Math.max(Altura(R.left),Altura(R.right))+1);
        x.altura = (int) (Math.max(Altura(x.left),Altura(x.right))+1);

        return x;
    } 

    public static NodoAVLarticles RotacionIzq(NodoAVLarticles x){
        NodoAVLarticles R = x.right;
        NodoAVLarticles T2 = R.left;

        R.left = x;
        x.right = T2;

        x.altura = (int) (Math.max(Altura(x.left),Altura(x.right))+1);
        R.altura = (int) (Math.max(Altura(R.left),Altura(R.right))+1);

        return R ;
    }

    public static int Balanceado(NodoAVLarticles R){
        if(R == null)
            return 0;
        return Altura(R.left)-Altura(R.right);
    }

    public NodoAVLarticles Insert(String num,Articulos articulos,  NodoAVLarticles node){
        if(node == null)
            return(new NodoAVLarticles(num,articulos));

        if(num.compareTo(node.data) < 0 )
            node.left = Insert(num,articulos,node.left);
        else if(num.compareTo(node.data)>=0)
            node.right = Insert(num,articulos,node.right);
            
        node.altura = (int) (1 + Math.max(Altura(node.left),Altura(node.right)));

        int Bal = Balanceado(node);

        if(Bal > 1 &&num.compareTo(node.data) < 0){
            return RotacionDer(node);
        }

         if(Bal < -1 && num.compareTo(node.data)>0){
            return RotacionIzq(node);
        }

          if (Bal > 1 && num.compareTo(node.data)>0) { 
            node.left = RotacionIzq(node.left); 
            return RotacionDer(node); 
        } 


        if (Bal < -1 && num.compareTo(node.data) < 0) { 
            node.right = RotacionDer(node.right); 
            return RotacionIzq(node); 
        } 

        return node;
    }
    
    
     public NodoAVLarticles FindMin(NodoAVLarticles Raiz){
        if(Raiz == null)
            return null;
        while(Raiz.left != null){
            Raiz = Raiz.left;
        }
        return Raiz;
    }
    
    public NodoAVLarticles FindMax(NodoAVLarticles Raiz){
        if(Raiz == null)
            return null;
        while(Raiz.right != null){
            Raiz = Raiz.right;
            }
        return Raiz;
    }
    
    public NodoAVLarticles Find(String dato, NodoAVLarticles Raiz) {
        return encontrar(dato, Raiz);
    }
    private NodoAVLarticles encontrar(String dato, NodoAVLarticles n) {
    while(n != null)
        if(dato.compareTo(n.data) < 0)
        n = n.left;
        else if(dato.compareTo(n.data)>0)
        n = n.right;
        else
        return n;    // Lo encontro

    throw new RuntimeException("Usuario no existente");   // No lo encontro.
    } 
       
  
    public int Height(String dato, NodoAVLarticles Raiz){
        NodoAVLarticles Aux = Find(dato,Raiz);
        if(Aux == null)
            return -1;
        else
            return (Aux.altura-1);
    }
    
    public int NumberNodes(String dato , NodoAVLarticles Raiz){
         NodoAVLarticles Aux = Find(dato, Raiz);
         NodoAVLarticles Aux1 = Aux;
         int cont=1;
         if(Aux == null)
             return 0;
         else{
            while(Aux.left != null){
                Aux = Aux.left;
                cont++;
            }
            while(Aux1.right != null){
                Aux1 = Aux1.right;
                cont++;
           }
         }
         return cont;
    }
    
    public boolean empty(){
        return Raiz==null;
    }
    
        public void inOrden_save(NodoAVLarticles n){
           
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                inOrden_save(n.left);
                
                stack.push(n);
                //System.out.println(n.num);
                inOrden_save(n.right);
                }
            }
    }
    
        String barra=File.separator;
    
    	public void saveArticle(AVLarticles binaryTree, String name) {
            
            String ubicacion = System.getProperty("user.dir")+ barra + "src" + barra + "main"+ barra + "java"+ barra + "txt"+ barra + "usuarios"+ barra + name + ".txt";
		FileWriter fl = null;
		try {
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
                        binaryTree.inOrden_save(Raiz);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!stack.isEmpty()) {
				//escribe los datos en el archivo
                                NodoAVLarticles art = (NodoAVLarticles)stack.pop();
                                Articulos articulos=art.getArticulos();
                                //System.out.println(String.valueOf(usu.getIndentificacion()));
				fl.write(articulos.getName()+ "," +
                                        String.valueOf(articulos.getCode())+ ","+
                                        articulos.getImage()+","+
                                        String.valueOf(articulos.getPrice())+","+
                                        String.valueOf(articulos.getAntiquity())+","+
                                        articulos.getBrand()+","+
                                        articulos.getDescription()+"\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        public AVLarticles chrageFileArticle(String name) {
            
            String ubicacion = System.getProperty("user.dir")+ barra + "src" + barra + "main"+ barra + "java"+ barra + "txt"+ barra + "usuarios"+ barra + name + ".txt";
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		AVLarticles binaryTree= new AVLarticles();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        String nameAux;
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                name=delimitar.next();
                                Articulos user =new Articulos(name,
                                    Integer.parseInt(delimitar.next()),
                                    delimitar.next(),
                                    Double.parseDouble(delimitar.next()),
                                    Integer.parseInt(delimitar.next()),
                                    delimitar.next(),
                                    delimitar.next());
                               binaryTree.setRaiz(binaryTree.Insert(name,
                                    user, binaryTree.getRaiz()));
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return binaryTree;
	}
}
