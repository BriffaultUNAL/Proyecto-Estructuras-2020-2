/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;
import App.Articulos;
import App.Usuario;
import DataEstructures.TreeNode;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import DataEstructures.*;
import static Interfaz.interfaz_principal.ids;

/**
 *
 * @author ANGEL
 */
public class BinaryTree <T>{
    
    private TreeNode<T> root;
    StackrefGeneric <T> stack = new StackrefGeneric<>();
    public BinaryTree() {
        this.root = null;
    }
    
    boolean empty(){
        return root == null;
    }
    public TreeNode getRoot(){
        return root;
    }
    // insertar nodo
    
    public void insertNode(T item,int num){
        
        TreeNode<T> newNode = new TreeNode<>(item,num); 
        
        if(empty()){
            root = newNode;
        }else if(search(num) == true){
             System.out.println("Ya existe");
        }else{
            TreeNode<T> aux=root;
            TreeNode<T> father;
            
            while(true){
                father=aux;
                
                if(num<aux.num){
                    aux=aux.leftSon;
                    if(aux==null){
                        father.leftSon=newNode;
                        return;
                    }
                }else{
                    aux=aux.rightSon;
                    if(aux==null){
                        father.rightSon=newNode;
                        return;
                    }
                }
            }
        }
        
        
    }
    
    public Object getItemRoot() {
        return root.item;
    }
    
    public void inOrden(TreeNode<T> n){
        
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                inOrden(n.leftSon);
                //System.out.println(n.item);
                inOrden(n.rightSon);
                }
            }
        
        
    }
    public void inOrden_save(TreeNode<T> n){
           
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                inOrden_save(n.leftSon);
                stack.push(n.item);
                //System.out.println(n.num);
                inOrden_save(n.rightSon);
                }
            }
    }
    
    public void preOrden(TreeNode<T> n){
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                System.out.println(n.item);
                preOrden(n.leftSon);
                preOrden(n.rightSon);
                }
            }
    }
    
    public void postOrden(TreeNode<T> n){
        
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                
                postOrden(n.leftSon);
                postOrden(n.rightSon);
                System.out.println(n.item);
                }
            }
    }
    
    public boolean search (int num){
        
        TreeNode<T> aux=root;
        boolean found;
        
        while(aux.num!=num){
            if (num<aux.num){
                aux=aux.leftSon;
            }else{
                aux=aux.rightSon;
            }
            if(aux==null){
                found=false;
                return  found;
            }
        }
        found=true;
        return found;
    }
    public Object search_node (int num){
        
        TreeNode<T> aux=root;
        
        boolean found;
        
        while(aux.num!=num){
            if (num<aux.num){
                aux=aux.leftSon;
            }else{
                aux=aux.rightSon;
            }
            if(aux==null){
                found=false;
                return null;
            }
        }
        found=true;
        return aux.item;
    }
    
    public boolean remove(int num){
        
        TreeNode<T> aux=root;
        TreeNode<T> father =root;
        boolean isLeftSon=false;
        
        while (aux.num!=num){
            father=aux;
            if(num<aux.num){
                isLeftSon=true;
                aux=aux.leftSon;
            }else{
                isLeftSon=false;
                aux=aux.rightSon;
            }
            if(aux==null){
                throw new RuntimeException("item not found");
            }      
        }
        
        if(aux.leftSon==null && aux.rightSon==null){
            if(aux==root){
                root=null;
            }else if(isLeftSon){
                father.leftSon=null;
            }else{
                father.rightSon=null;
            }
        }else if(aux.leftSon==null){
            if(aux==root){
                root=aux.rightSon;
            }else if(isLeftSon){
                father.leftSon=aux.rightSon;
            }else{
                father.rightSon=aux.rightSon;
            }
        }else if(aux.rightSon==null){
            if(aux==root){
                root=aux.leftSon;
            }else if(isLeftSon){
                father.leftSon=aux.leftSon; 
            }else{
                father.rightSon=aux.leftSon;
            }
        }else{
            TreeNode<T> replacement = removeBST(aux);
            if(aux==root){
                root=replacement;
            }else if(isLeftSon){
                father.leftSon=replacement;
            }else{
                father.rightSon=replacement;
            }
            replacement.leftSon=aux.leftSon;
        }
        return true;
    }
    
    public TreeNode removeBST(TreeNode<T> nodeRemove){
        
        TreeNode<T> replaceFather=nodeRemove;
        TreeNode<T> replace=nodeRemove;
        TreeNode<T> aux=nodeRemove.rightSon;
        while(aux!=null){
            replaceFather=replace;
            replace=aux;
            aux=aux.leftSon;
        }
        if(replace!=nodeRemove.rightSon){
            replaceFather.leftSon=replace.rightSon;
            replace.rightSon=nodeRemove.rightSon;
        }
        return replace;
    }
  
    String barra=File.separator;
 /*   
    	public void saveUser(BinaryTree<T> binaryTree, String name) {
            
            String ubicacion = ids + "\\src\\main\\java\\txt\\usuarios\\" + name + ".txt";
		FileWriter fl = null;
		try {
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
                        binaryTree.inOrden_save(root);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!stack.isEmpty()) {
				//escribe los datos en el archivo
                                Usuario usu = (Usuario)stack.pop();
                                //System.out.println(String.valueOf(usu.getIndentificacion()));
				fl.write(String.valueOf(usu.getIndentificacion())+ "," +
                                        usu.getNombre() + "," +
                                        usu.getContrasena() + "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        public BinaryTree chrageFileUser(String name) {
            
            String ubicacion = ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		BinaryTree<Object> binaryTree= new BinaryTree<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Usuario user =new Usuario(
                                    delimitar.next()
                                    ,delimitar.next());
                               binaryTree.insertNode(user.getNombre(), user.getContrasena());
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return binaryTree;
	}
  */      
        
        public void saveArticle(BinaryTree<T> binaryTree, String name) {
            
            String ubicacion= ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		FileWriter fl = null;
		try {
			//crea el flujo para escribir en el archivo
			fl = new FileWriter(ubicacion);
                        binaryTree.inOrden_save(root);
			//crea un buffer o flujo intermedio antes de escribir directamente en el archivo
			while(!stack.isEmpty()) {
				//escribe los datos en el archivo
                                Articulos articulo=(Articulos)stack.pop();
				fl.write(articulo.getName()+ "," +
                                        String.valueOf(articulo.getCode()) + "," +
                                        articulo.getImage()+ "," +
                                        String.valueOf(articulo.getPrice()) + "," +
                                        String.valueOf(articulo.getAntiquity()) + "," +
                                        articulo.getBrand() + "," +
                                        articulo.getDescription()+ "\n");
			}
			//cierra el buffer intermedio
			fl.close();
			System.out.println("Archivo creado satisfactoriamente..");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fl != null) {
				try {//cierra el flujo principal
					fl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
        
        public BinaryTree chrageFileArticle(String name) {
            
            String ubicacion = ids + "\\src\\main\\java\\txt\\usuarios\\"+ name + ".txt";
		// crea el flujo para leer desde el archivo
		File file = new File(ubicacion);
		BinaryTree<Object> binaryTree= new BinaryTree<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
                        
                        while (scanner.hasNextLine()){
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
                                Articulos articulo =new Articulos(delimitar.next()
                                    ,Integer.parseInt(delimitar.next())
                                    ,delimitar.next()
                                    ,Double.parseDouble(delimitar.next())
                                    , Integer.parseInt(delimitar.next())
                                    , delimitar.next()
                                    , delimitar.next());
                               binaryTree.insertNode(articulo,articulo.getCode());
                        }
			//se cierra el ojeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return binaryTree;
	}  

}
