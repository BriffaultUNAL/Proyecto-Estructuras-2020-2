/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

import java.io.Serializable;

/**
 *
 * @author ANGEL
 */
   public class Nodo<T>implements Serializable{
    
    private T item;
    
    private Nodo<T> next;
    
    public Nodo(T item, Nodo <T> next){
        this.item=item;
        this.next=next;
    }

    public T getItem() {
        return item;
    }

    public void setItem(T item) {
        this.item = item;
    }

    public Nodo<T> getNext() {
        return next;
    }

    public void setNext(Nodo<T> next) {
        this.next = next;
    }
    
}

