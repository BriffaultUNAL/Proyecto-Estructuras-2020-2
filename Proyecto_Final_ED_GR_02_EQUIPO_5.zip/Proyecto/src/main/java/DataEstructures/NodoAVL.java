/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

/**
 *
 * @author ANGEL
 */
public class NodoAVL {
       
        String data;
        String password;
        int altura,repetido;
        NodoAVL left=null, right=null;

        public NodoAVL(String data, String password) {
            this.data = data;
            this.password=password;
            altura = 1;
            repetido = 1;
        }

        public String getPassword() {
            return password;
        }

        public String getData() {
            return data;
        }

        public int getAltura() {
            return altura;
        }

        public int getRepetido() {
            return repetido;
        }
    
}
