/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;
import App.Articulos;

/**
 *
 * @author ANGEL
 */
public class NodoAVLarticles {
        String data;
        Articulos articulos;
        int altura,repetido;
        NodoAVLarticles left=null, right=null;

        public NodoAVLarticles(String data, Articulos articulos) {
            this.data = data;
            this.articulos=articulos;
            altura = 1;
            repetido = 1;
        }

    public Articulos getArticulos() {
        return articulos;
    }

        

        public String getData() {
            return data;
        }

        public int getAltura() {
            return altura;
        }

        public int getRepetido() {
            return repetido;
        }
}
