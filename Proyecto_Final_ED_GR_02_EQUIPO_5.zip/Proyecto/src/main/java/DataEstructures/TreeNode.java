/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

/**
 *
 * @author ANGEL
 */
public class TreeNode<T> {
    
    T item;
    int num;
    TreeNode<T> leftSon;
    TreeNode<T> rightSon;

    public TreeNode(T item,int num){
        this.item = item;
        this.num=num;
        this.leftSon = null;
        this.rightSon = null;
    }
    
}
