/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEstructures;

/**
 *
 * @author ANGEL
 */
public class BinaryTreeAVL<T> {
    
    private TreeNodeAVL <T> root;
    
    public BinaryTreeAVL(){
        root=null;
    }
    
    boolean empty(){
        return root==null;
    }
    
    public TreeNodeAVL searchAVL(int num,TreeNodeAVL<T> n){
        
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else if(n!=null){
            if(n.num==num){
                return n;
            }else if(n.num<num){
                return searchAVL(num, n.righttSon);
            }else{
                return searchAVL(num, n.leftSon);
        }
        }else{
            System.err.println("item not found");
            return n;
        }
        
    }
    
    public  int FE(TreeNodeAVL<T> n){
        
        if(n==null){
            return -1;
        }else{
            return n.fe;
        }
        
    }
    
    public TreeNodeAVL leftRotation(TreeNodeAVL<T> n){
        
        TreeNodeAVL<T> aux=n.leftSon;
        n.leftSon=aux.righttSon;
        aux.righttSon=n;
        n.fe=Math.max(FE(n.leftSon),FE(n.righttSon))+1;
        aux.fe=Math.max(FE(aux.leftSon),FE(aux.righttSon))+1;
        return aux;
    }
    
    public TreeNodeAVL rightRotation(TreeNodeAVL<T> n){
        
        TreeNodeAVL<T> aux=n.righttSon;
        n.righttSon=aux.leftSon;
        aux.leftSon=n;
        n.fe=Math.max(FE(n.leftSon),FE(n.righttSon))+1;
        aux.fe=Math.max(FE(aux.leftSon),FE(aux.righttSon))+1;
        return aux;
    }
    
    public TreeNodeAVL doubleLeftRotation(TreeNodeAVL<T> nodeAVL){
        
        TreeNodeAVL<T> temp;
        nodeAVL.leftSon=rightRotation(nodeAVL.leftSon);
        temp=leftRotation(nodeAVL);
        return temp;
        
    }
    
    public TreeNodeAVL doubleRightRotation(TreeNodeAVL<T> nodeAVL){
        
        TreeNodeAVL<T> temp;
        nodeAVL.righttSon=leftRotation(nodeAVL.righttSon);
        temp=rightRotation(nodeAVL);
        return temp;
        
    }
    
    public TreeNodeAVL insertAVL(TreeNodeAVL<T> newAVL,TreeNodeAVL<T> subAr){
        TreeNodeAVL<T> newFather=subAr;
        if(newAVL.num<subAr.num){
            if(subAr.leftSon==null){
                subAr.leftSon=newAVL;
            }else{
                subAr.leftSon=insertAVL(newAVL, subAr.leftSon);
                if((FE(subAr.leftSon)-FE(subAr.righttSon))==2){
                    if(newAVL.num<subAr.leftSon.num){
                        newFather=leftRotation(subAr);
                    }else{
                        newFather=doubleLeftRotation(subAr);
                    }
                }
            }
        }else if(newAVL.num>subAr.num){
            if(subAr.righttSon==null){
                subAr.righttSon=newAVL;
            }else{
                subAr.righttSon=insertAVL(newAVL, subAr.righttSon);
                if((FE(subAr.righttSon)-FE(subAr.leftSon))==2){
                    if(newAVL.num>subAr.righttSon.num){
                        newFather=rightRotation(subAr);
                    }else{
                        newFather=doubleRightRotation(subAr);
                    }
                }
            }
        }else{
            
        }
        
        if(subAr.leftSon==null&&subAr.righttSon!=null){
            subAr.fe=subAr.righttSon.fe+1;
        }else if(subAr.righttSon==null&&subAr.leftSon!=null){
            subAr.fe=subAr.leftSon.fe+1;
        }else{
            subAr.fe=Math.max(FE(subAr.leftSon), FE(subAr.righttSon))+1;
        }
        return newFather;
    }
    
    public void insert(int num, T item){
        TreeNodeAVL<T> newAVL=new TreeNodeAVL<>(num,item);
        if(empty()){
            root=newAVL;
        }else{
            root=insertAVL(newAVL, root);
        }
    }
    
        public void inOrden(TreeNodeAVL<T> n){
        
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                inOrden(n.leftSon);
                System.out.println(n.item);
                inOrden(n.righttSon);
                }
            }
        
        
    }
    
    public void preOrden(TreeNodeAVL<T> n){
        
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                System.out.println(n.item);
                preOrden(n.leftSon);
                preOrden(n.righttSon);
                }
            }
    }
    
    public void postOrden(TreeNodeAVL<T> n){
        
        if(empty()){
            throw new RuntimeException("Tree is empty");
        }else{
            if(n!=null){
                
                postOrden(n.leftSon);
                postOrden(n.righttSon);
                System.out.println(n.item);
                }
            }
    }
    
    public TreeNodeAVL getRoot(){
        return root;
    }
    
    public boolean remove(int num){
        
        TreeNodeAVL<T> aux=root;
        TreeNodeAVL<T> father =root;
        boolean isLeftSon=false;
        
        while (aux.num!=num){
            father=aux;
            if(num<aux.num){
                isLeftSon=true;
                aux=aux.leftSon;
            }else{
                isLeftSon=false;
                aux=aux.righttSon;
            }
            if(aux==null){
                throw new RuntimeException("item not found");
            }      
        }
        
        if(aux.leftSon==null && aux.righttSon==null){
            if(aux==root){
                root=null;
            }else if(isLeftSon){
                father.leftSon=null;
            }else{
                father.righttSon=null;
            }
        }else if(aux.leftSon==null){
            if(aux==root){
                root=aux.righttSon;
            }else if(isLeftSon){
                father.leftSon=aux.righttSon;
            }else{
                father.righttSon=aux.righttSon;
            }
        }else if(aux.righttSon==null){
            if(aux==root){
                root=aux.leftSon;
            }else if(isLeftSon){
                father.leftSon=aux.leftSon; 
            }else{
                father.righttSon=aux.leftSon;
            }
        }else{
            TreeNodeAVL<T> replacement = removeBST(aux);
            if(aux==root){
                root=replacement;
            }else if(isLeftSon){
                father.leftSon=replacement;
            }else{
                father.righttSon=replacement;
            }
            replacement.leftSon=aux.leftSon;
        }
        return true;
    }
    
    public TreeNodeAVL removeBST(TreeNodeAVL<T> nodeRemove){
        
        TreeNodeAVL<T> replaceFather=nodeRemove;
        TreeNodeAVL<T> replace=nodeRemove;
        TreeNodeAVL<T> aux=nodeRemove.righttSon;
        while(aux!=null){
            replaceFather=replace;
            replace=aux;
            aux=aux.leftSon;
        }
        if(replace!=nodeRemove.righttSon){
            replaceFather.leftSon=replace.righttSon;
            replace.righttSon=nodeRemove.righttSon;
        }
        return replace;
    }
}
